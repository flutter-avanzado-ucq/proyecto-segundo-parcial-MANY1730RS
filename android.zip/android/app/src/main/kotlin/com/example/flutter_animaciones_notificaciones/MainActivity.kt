package com.example.flutter_animaciones_notificaciones

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
